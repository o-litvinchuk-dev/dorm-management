import pool from "../config/db.js";

const Group = {
  async create({ faculty_id, name }) {
    const [result] = await pool.execute(
      `INSERT INTO groups (faculty_id, name) VALUES (?, ?)`,
      [faculty_id, name]
    );
    return result.insertId;
  },

  async findAllByFacultyId(faculty_id) {
    const [rows] = await pool.execute(
      `SELECT id, name, faculty_id FROM groups WHERE faculty_id = ?`,
      [faculty_id]
    );
    return rows;
  },

  async findById(id) {
    const [rows] = await pool.execute(
      `SELECT id, name, faculty_id FROM groups WHERE id = ?`,
      [id]
    );
    return rows[0] || null;
  },

  async update(id, { name }) {
    const [result] = await pool.execute(
      `UPDATE groups SET name = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`,
      [name, id]
    );
    return result.affectedRows > 0;
  },

  async delete(id) {
    const [result] = await pool.execute(`DELETE FROM groups WHERE id = ?`, [id]);
    return result.affectedRows > 0;
  },
};

export default Group;