import pool from "../config/db.js";
import Dormitories from '../models/Dormitory.js'; // Adjust to match actual file name

const Dormitory = {
  async create({ name, address }) {
    const [result] = await pool.execute(
      `INSERT INTO dormitories (name, address) VALUES (?, ?)`,
      [name, address || null]
    );
    return result.insertId;
  },

  async findAll() {
    const [rows] = await pool.execute(`SELECT * FROM dormitories`);
    return rows;
  },

  async findById(id) {
    const [rows] = await pool.execute(`SELECT * FROM dormitories WHERE id = ?`, [id]);
    return rows[0] || null;
  },

  async update(id, { name, address }) {
    const [result] = await pool.execute(
      `UPDATE dormitories SET name = ?, address = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`,
      [name, address || null, id]
    );
    return result.affectedRows > 0;
  },

  async delete(id) {
    const [result] = await pool.execute(`DELETE FROM dormitories WHERE id = ?`, [id]);
    return result.affectedRows > 0;
  },
};

export default Dormitory;