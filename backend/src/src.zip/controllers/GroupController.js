import Joi from "joi";
import Group from "../models/Group.js";

export const createGroup = async (req, res) => {
  try {
    const { facultyId } = req.params;
    const schema = Joi.object({
      name: Joi.string().min(3).max(100).required(),
    });

    const { error, value } = schema.validate(req.body);
    if (error) {
      return res.status(400).json({ error: "Невірні дані", details: error.details });
    }

    if (req.user.role === "faculty_dean_office" && req.user.faculty_id !== facultyId) {
      return res.status(403).json({ error: "Доступ обмежено до вашого факультету" });
    }

    const groupId = await Group.create({ faculty_id: facultyId, ...value });
    res.status(201).json({ message: "Групу створено", groupId });
  } catch (error) {
    console.error("[GroupController] Помилка створення групи:", error);
    res.status(500).json({ error: "Помилка сервера" });
  }
};

export const getGroups = async (req, res) => {
  try {
    const { facultyId } = req.params;
    if (req.user.role === "faculty_dean_office" && req.user.faculty_id !== facultyId) {
      return res.status(403).json({ error: "Доступ обмежено до вашого факультету" });
    }

    const groups = await Group.findAllByFacultyId(facultyId);
    res.json(groups);
  } catch (error) {
    console.error("[GroupController] Помилка отримання груп:", error);
    res.status(500).json({ error: "Помилка сервера" });
  }
};

export const updateGroup = async (req, res) => {
  try {
    const { id } = req.params;
    const schema = Joi.object({
      name: Joi.string().min(3).max(100).required(),
    });

    const { error, value } = schema.validate(req.body);
    if (error) {
      return res.status(400).json({ error: "Невірні дані", details: error.details });
    }

    const group = await Group.findById(id);
    if (!group) {
      return res.status(404).json({ error: "Групу не знайдено" });
    }

    if (req.user.role === "faculty_dean_office" && req.user.faculty_id !== group.faculty_id) {
      return res.status(403).json({ error: "Доступ обмежено до вашого факультету" });
    }

    const updated = await Group.update(id, value);
    if (!updated) {
      return res.status(404).json({ error: "Групу не знайдено" });
    }

    res.json({ message: "Групу оновлено" });
  } catch (error) {
    console.error("[GroupController] Помилка оновлення групи:", error);
    res.status(500).json({ error: "Помилка сервера" });
  }
};

export const deleteGroup = async (req, res) => {
  try {
    const { id } = req.params;
    const group = await Group.findById(id);
    if (!group) {
      return res.status(404).json({ error: "Групу не знайдено" });
    }

    if (req.user.role === "faculty_dean_office" && req.user.faculty_id !== group.faculty_id) {
      return res.status(403).json({ error: "Доступ обмежено до вашого факультету" });
    }

    const deleted = await Group.delete(id);
    if (!deleted) {
      return res.status(404).json({ error: "Групу не знайдено" });
    }

    res.json({ message: "Групу видалено" });
  } catch (error) {
    console.error("[GroupController] Помилка видалення групи:", error);
    res.status(500).json({ error: "Помилка сервера" });
  }
};