import Joi from "joi";
import Dormitory from "../models/Dormitory.js";

export const createDormitory = async (req, res) => {
  try {
    const schema = Joi.object({
      name: Joi.string().min(3).max(100).required(),
      address: Joi.string().max(255).optional(),
    });

    const { error, value } = schema.validate(req.body);
    if (error) {
      return res.status(400).json({ error: "Невірні дані", details: error.details });
    }

    const dormitoryId = await Dormitory.create(value);
    res.status(201).json({ message: "Гуртожиток створено", dormitoryId });
  } catch (error) {
    console.error("[DormitoryController] Помилка створення гуртожитку:", error);
    res.status(500).json({ error: "Помилка сервера" });
  }
};

export const getDormitories = async (req, res) => {
  try {
    const dormitories = await Dormitory.findAll();
    res.json(dormitories);
  } catch (error) {
    console.error("[DormitoryController] Помилка отримання гуртожитків:", error);
    res.status(500).json({ error: "Помилка сервера" });
  }
};

export const getDormitoryById = async (req, res) => {
  try {
    const { id } = req.params;
    const dormitory = await Dormitory.findById(id);
    if (!dormitory) {
      return res.status(404).json({ error: "Гуртожиток не знайдено" });
    }
    res.json(dormitory);
  } catch (error) {
    console.error("[DormitoryController] Помилка отримання гуртожитку:", error);
    res.status(500).json({ error: "Помилка сервера" });
  }
};

export const updateDormitory = async (req, res) => {
  try {
    const { id } = req.params;
    const schema = Joi.object({
      name: Joi.string().min(3).max(100).required(),
      address: Joi.string().max(255).optional(),
    });

    const { error, value } = schema.validate(req.body);
    if (error) {
      return res.status(400).json({ error: "Невірні дані", details: error.details });
    }

    const updated = await Dormitory.update(id, value);
    if (!updated) {
      return res.status(404).json({ error: "Гуртожиток не знайдено" });
    }
    res.json({ message: "Гуртожиток оновлено" });
  } catch (error) {
    console.error("[DormitoryController] Помилка оновлення гуртожитку:", error);
    res.status(500).json({ error: "Помилка сервера" });
  }
};

export const deleteDormitory = async (req, res) => {
  try {
    const { id } = req.params;
    const deleted = await Dormitory.delete(id);
    if (!deleted) {
      return res.status(404).json({ error: "Гуртожиток не знайдено" });
    }
    res.json({ message: "Гуртожиток видалено" });
  } catch (error) {
    console.error("[DormitoryController] Помилка видалення гуртожитку:", error);
    res.status(500).json({ error: "Помилка сервера" });
  }
};