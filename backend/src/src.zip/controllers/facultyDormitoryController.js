import FacultyDormitories from "../models/FacultyDormitories.js";
import Faculties from "../models/Faculties.js";
import Dormitories from '../models/Dormitory.js'; // Adjust to match actual file name
import Joi from "joi";

export const createFacultyDormitory = async (req, res) => {
  try {
    const schema = Joi.object({
      faculty_id: Joi.number().integer().positive().required(),
      dormitory_id: Joi.number().integer().positive().required(),
      quota: Joi.number().integer().min(0).optional(),
    });

    const { error, value } = schema.validate(req.body);
    if (error) {
      return res.status(400).json({ error: "Невірні дані", details: error.details });
    }

    const { faculty_id, dormitory_id, quota } = value;

    // Verify faculty exists
    const faculty = await Faculties.findById(faculty_id);
    if (!faculty) {
      return res.status(404).json({ error: `Факультет з ID ${faculty_id} не знайдено` });
    }

    // Verify dormitory exists
    const dormitory = await Dormitories.findById(dormitory_id);
    if (!dormitory) {
      return res.status(404).json({ error: `Гуртожиток з ID ${dormitory_id} не знайдено` });
    }

    // Check for duplicate faculty-dormitory pair
    const existing = await FacultyDormitories.findByIds(faculty_id, dormitory_id);
    if (existing) {
      return res.status(400).json({ error: "Цей факультет уже пов’язаний із цим гуртожитком" });
    }

    const facultyDormitoryId = await FacultyDormitories.create(value);
    res.status(201).json({ message: "Зв'язок створено", facultyDormitoryId });
  } catch (error) {
    console.error("[FacultyDormitoryController] Помилка створення зв'язку:", error);
    res.status(500).json({ error: "Помилка сервера", details: error.message });
  }
};

export const getFacultyDormitories = async (req, res) => {
  try {
    const records = await FacultyDormitories.findAll();
    res.json(records);
  } catch (error) {
    console.error("[FacultyDormitoryController] Помилка отримання:", error);
    res.status(500).json({ error: "Помилка сервера", details: error.message });
  }
};

export const updateFacultyDormitory = async (req, res) => {
  try {
    const { faculty_id, dormitory_id } = req.params;

    // Validate faculty_id and dormitory_id
    const idSchema = Joi.object({
      faculty_id: Joi.number().integer().positive().required(),
      dormitory_id: Joi.number().integer().positive().required(),
    });
    const { error: idError } = idSchema.validate({ faculty_id, dormitory_id });
    if (idError) {
      return res.status(400).json({ error: "Невірні ID", details: idError.details });
    }

    // Verify faculty exists
    const faculty = await Faculties.findById(faculty_id);
    if (!faculty) {
      return res.status(404).json({ error: `Факультет з ID ${faculty_id} не знайдено` });
    }

    // Verify dormitory exists
    const dormitory = await Dormitories.findById(dormitory_id);
    if (!dormitory) {
      return res.status(404).json({ error: `Гуртожиток з ID ${dormitory_id} не знайдено` });
    }

    // Validate update data
    const schema = Joi.object({
      quota: Joi.number().integer().min(0).optional().allow(null),
    });
    const { error, value } = schema.validate(req.body);
    if (error) {
      return res.status(400).json({ error: "Невірні дані", details: error.details });
    }

    const updated = await FacultyDormitories.update(faculty_id, dormitory_id, value);
    if (!updated) {
      return res.status(404).json({ error: "Запис не знайдено" });
    }
    res.json({ message: "Запис оновлено" });
  } catch (error) {
    console.error("[FacultyDormitoryController] Помилка оновлення:", error);
    res.status(500).json({ error: "Помилка сервера", details: error.message });
  }
};

export const deleteFacultyDormitory = async (req, res) => {
  try {
    const { faculty_id, dormitory_id } = req.params;

    // Validate faculty_id and dormitory_id
    const idSchema = Joi.object({
      faculty_id: Joi.number().integer().positive().required(),
      dormitory_id: Joi.number().integer().positive().required(),
    });
    const { error: idError } = idSchema.validate({ faculty_id, dormitory_id });
    if (idError) {
      return res.status(400).json({ error: "Невірні ID", details: idError.details });
    }

    // Verify record exists
    const existing = await FacultyDormitories.findByIds(faculty_id, dormitory_id);
    if (!existing) {
      return res.status(404).json({ error: "Запис не знайдено" });
    }

    const deleted = await FacultyDormitories.delete(faculty_id, dormitory_id);
    if (!deleted) {
      return res.status(404).json({ error: "Запис не знайдено" });
    }
    res.json({ message: "Запис видалено" });
  } catch (error) {
    console.error("[FacultyDormitoryController] Помилка видалення:", error);
    res.status(500).json({ error: "Помилка сервера", details: error.message });
  }
};