import { Router } from "express";
import { authenticate, authorize } from "../../middlewares/auth.js";
import Dormitory from "../../models/Dormitory.js";

const router = Router();

router.get(
  "/dormitories",
  authenticate,
  authorize("GET", "/api/v1/dormitories"),
  async (req, res) => {
    try {
      const dormitories = await Dormitory.findAll();
      res.json(dormitories.map((d) => ({ id: d.id, name: d.name })));
    } catch (error) {
      console.error("[DormitoryRoutes] Error fetching dormitories:", error);
      res.status(500).json({ error: "Server error" });
    }
  }
);

export default router;