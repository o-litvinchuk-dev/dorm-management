import React from "react";

const SecuritySettings = () => {
  return (
    <div>
      <h2>Налаштування безпеки</h2>
      <p>Тут будуть поля для зміни пароля чи двофакторної аутентифікації.</p>
    </div>
  );
};

export default SecuritySettings;