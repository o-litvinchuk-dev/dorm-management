import React from "react";

const NotificationSettings = () => {
  return (
    <div>
      <h2>Налаштування сповіщень</h2>
      <p>Тут будуть опції для увімкнення/вимкнення сповіщень.</p>
    </div>
  );
};

export default NotificationSettings;