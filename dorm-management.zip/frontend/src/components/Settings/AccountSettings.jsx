import React from "react";

const AccountSettings = () => {
  return (
    <div>
      <h2>Налаштування облікового запису</h2>
      <p>Тут будуть поля для зміни імені, email тощо.</p>
    </div>
  );
};

export default AccountSettings;