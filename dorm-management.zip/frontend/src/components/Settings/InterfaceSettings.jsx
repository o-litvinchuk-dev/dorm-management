import React from "react";

const InterfaceSettings = () => {
  return (
    <div>
      <h2>Налаштування інтерфейсу</h2>
      <p>Тут будуть опції для зміни теми чи мови.</p>
    </div>
  );
};

export default InterfaceSettings;