import pool from "../config/db.js";
import DormApplication from "../models/DormApplication.js";
import Dormitory from "../models/Dormitory.js";
import Settlement from "../models/Settlement.js";
import AccommodationApplication from "../models/AccommodationApplication.js";

export const getDashboardData = async (req, res) => {
  try {
    const userId = req.user.userId;
    const [applications] = await pool.execute(
      `
      (SELECT id, user_id, name, surname, faculty, course, NULL as group_name, NULL as phone_number, NULL as dorm_number, NULL as start_date, NULL as end_date, NULL as application_date, NULL as status, created_at 
       FROM dorm_applications 
       WHERE user_id = ?)
      UNION
      (SELECT id, user_id, full_name as name, surname, faculty, course, group_name, phone_number, dorm_number, start_date, end_date, application_date, status, created_at 
       FROM accommodation_applications 
       WHERE user_id = ?)
      ORDER BY created_at DESC LIMIT 5
      `,
      [userId, userId]
    );
    const [notifications] = await pool.execute(
      `SELECT id, title, description, created_at, \`read\` 
       FROM notifications 
       WHERE user_id = ? 
       ORDER BY created_at DESC LIMIT 5`,
      [userId]
    );
    res.json({
      applications,
      notifications,
    });
  } catch (error) {
    console.error("[SecureController] Помилка отримання даних дашборду:", error);
    res.status(500).json({ error: "Помилка сервера" });
  }
};

export const getApplications = async (req, res) => {
  try {
    const userId = req.user.userId;
    const [rows] = await pool.execute(
      `
      (SELECT id, user_id, name, surname, faculty, course, NULL as group_name, NULL as phone_number, NULL as dorm_number, NULL as start_date, NULL as end_date, NULL as application_date, NULL as status, created_at 
       FROM dorm_applications 
       WHERE user_id = ?)
      UNION
      (SELECT id, user_id, full_name as name, surname, faculty, course, group_name, phone_number, dorm_number, start_date, end_date, application_date, status, created_at 
       FROM accommodation_applications 
       WHERE user_id = ?)
      ORDER BY created_at DESC LIMIT 10
      `,
      [userId, userId]
    );
    res.json(rows);
  } catch (error) {
    console.error("[SecureController] Помилка отримання заявок:", error);
    res.status(500).json({ error: "Помилка сервера" });
  }
};

export const getDormitories = async (req, res) => {
  try {
    const dormitories = await Dormitory.findAll();
    res.json(dormitories);
  } catch (error) {
    console.error("[SecureController] Помилка отримання гуртожитків:", error);
    res.status(500).json({ error: "Помилка сервера" });
  }
};

export const getSettlements = async (req, res) => {
  try {
    const settlements = await Settlement.findAll();
    res.json(settlements);
  } catch (error) {
    console.error("[SecureController] Помилка отримання розкладу поселення:", error);
    res.status(500).json({ error: "Помилка сервера" });
  }
};

export const getAccommodationApplications = async (req, res) => {
  try {
    const userId = req.user.userId;
    const [rows] = await pool.execute(
      `
      SELECT id, user_id, full_name as name, surname, faculty, course, group_name, phone_number, dorm_number, start_date, end_date, application_date, status, created_at 
      FROM accommodation_applications 
      WHERE user_id = ? 
      ORDER BY created_at DESC LIMIT 10
      `,
      [userId]
    );
    res.json(rows);
  } catch (error) {
    console.error("[SecureController] Помилка отримання заявок на проживання:", error);
    res.status(500).json({ error: "Помилка сервера" });
  }
};